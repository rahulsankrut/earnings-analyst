import os
import glob
import logging

logger = logging.getLogger(__name__)

def read_historical_transcripts() -> str:
    """Reads all historical Trane earnings call transcripts (Q1, Q2, Q3 2025) into a single text block.
    
    This function is used to gather the historical context of what analysts have asked in the past.
    
    Returns:
        str: The combined text of all available markdown transcripts.
    """
    # Assuming the reports folder is at the root of the workspace being deployed
    # We will locate the reports folder relative to this file
    current_dir = os.path.dirname(__file__)
    # Go up 2 levels to the root of the poetry project, then to reports
    reports_dir = os.path.abspath(os.path.join(current_dir, "..", "..", "reports"))
    
    transcript_files = glob.glob(os.path.join(reports_dir, "*Transcript.md"))
    
    if not transcript_files:
        logger.warning(f"No transcript files found in {reports_dir}")
        return "No historical transcripts found."
        
    combined_text = []
    for file_path in sorted(transcript_files):
        filename = os.path.basename(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
            combined_text.append(f"--- START OF {filename} ---\n{content}\n--- END OF {filename} ---\n")
            
    return "\n\n".join(combined_text)
