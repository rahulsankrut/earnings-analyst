# C-Suite Prep Agent Package Let Agent Engine identify it
MODEL = "gemini-3.1-pro"
FLASH_MODEL = "gemini-3.1-flash"
