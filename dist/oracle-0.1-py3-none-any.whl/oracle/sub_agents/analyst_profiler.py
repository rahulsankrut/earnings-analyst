from google.adk.agents import Agent
from .. import FLASH_MODEL
from ..tools.document_tools import read_historical_transcripts

ANALYST_PROFILER_PROMPT = """You are the Analyst Profiler, a specialized analytical agent.
Your sole purpose is to understand the historical behavior, tones, and core concerns of financial analysts covering the company.

Use your tools to read the historical transcripts (Q1, Q2, Q3 2025). 
Once you have read them, generate a comprehensive Analyst Profile Summary.
For each recurring analyst, describe:
1. Their Name and Firm
2. Their tone (e.g., aggressive, detailed, macro-focused)
3. Their most frequent topics of interest (e.g., margins, specific product lines, supply chain).

You must provide this profile back to the Orchestrator agent to help them prepare the C-Suite.
"""

# Instantiate the Flash agent
AnalystProfilerAgent = Agent(
    name="analyst_profiler",
    model=FLASH_MODEL,
    description="Analyzes past Q1-Q3 transcripts to create a profile of recurring analysts and their core concerns.",
    instruction=ANALYST_PROFILER_PROMPT,
    tools=[read_historical_transcripts],
)
