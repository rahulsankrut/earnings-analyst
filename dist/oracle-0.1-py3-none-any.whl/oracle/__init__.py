# C-Suite Prep Agent Package Let Agent Engine identify it
MODEL = "gemini-2.5-pro"
FLASH_MODEL = "gemini-2.5-flash"
