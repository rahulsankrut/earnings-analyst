import os
import logging
import tempfile
import pdfplumber
from google.cloud import storage

logger = logging.getLogger(__name__)

BUCKET_NAME = "oracle-historical-docs"

def read_historical_documents() -> str:
    """Reads historical transcript and report PDFs directly from Google Cloud Storage.
    
    This function gathers the historical context (Q1-Q3 2025 and older years) to anticipate analyst questions.
    
    Returns:
        str: The combined text of all available historical PDFs.
    """
    try:
        client = storage.Client()
    except Exception as e:
        logger.error(f"Failed to initialize GCS Client: {e}")
        return "Failed to initialize Cloud Storage."

    bucket = client.bucket(BUCKET_NAME)
    blobs = list(bucket.list_blobs())
    
    # Process all PDF blobs in the bucket (transcripts + historical periodic reports)
    pdf_blobs = [b for b in blobs if b.name.endswith(".pdf")]
    
    if not pdf_blobs:
        logger.warning(f"No historical files found in gs://{BUCKET_NAME}")
        return "No historical PDF documents found in Cloud Storage."
        
    combined_text = []
    
    # Use a temporary directory to store downloaded PDFs
    with tempfile.TemporaryDirectory() as tmp_dir:
        for blob in pdf_blobs:
            filename = os.path.basename(blob.name)
            local_path = os.path.join(tmp_dir, filename)
            
            try:
                # Download to local temp file to use pdfplumber
                blob.download_to_filename(local_path)
                
                with pdfplumber.open(local_path) as pdf:
                    content = "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])
                combined_text.append(f"--- START OF {filename} ---\n{content}\n--- END OF {filename} ---\n")
            except Exception as e:
                logger.error(f"Failed to read {filename} from GCS: {e}")
            
    return "\n\n".join(combined_text)
