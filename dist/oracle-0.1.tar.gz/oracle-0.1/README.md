# C-Suite Earnings Prep Agent (ADK)

This project contains a Google ADK-based multi-agent system designed to review past analyst questions from Q1/Q2/Q3 transcripts and prepare C-Suite executives for Q4 questions based on dynamically provided 10-K inputs.

## Deployment to Vertex AI Agent Engine

It is meant to be packaged as a `.whl` and pushed to Vertex AI so it can be accessed natively via Gemini Enterprise UI.
